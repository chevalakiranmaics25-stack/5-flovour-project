Smart Plant Growth Monitoring and Prediction System — Data Visualization Graphs

Source dataset: plant growth dataset.csv
Rows read: 1000
Columns: 17

Generated charts:
1. 01_new_growth_distribution.png — distribution of New_Growth_Count.
2. 02_soil_moisture_vs_new_growth.png — relationship between soil moisture and New_Growth_Count.
3. 03_height_vs_new_growth.png — relationship between plant height and New_Growth_Count.
4. 04_average_growth_by_soil_type.png — average growth count grouped by soil type.
5. 05_average_growth_by_fertilizer.png — average growth count grouped by fertilizer type.

Presentation notes:
- These charts are generated from the source dataset, not invented sample values.
- A scatter plot shows association; it does not by itself prove that one variable causes growth.
- Group averages can be affected by sample sizes and other plant conditions.
- The dataset does not clearly provide repeated time-based measurements for each plant, so do not call the scatter plots a growth-over-time line chart.

Suggested Data Visualization (DV) explanation:
I use a histogram to understand the distribution of New_Growth_Count, scatter plots to explore how soil moisture and plant height relate to new growth, and bar charts to compare average new growth across soil and fertilizer categories.